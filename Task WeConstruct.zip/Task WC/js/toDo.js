
export class Todo{
    static idItem = null
    static toDo = {}
    static contentDo = undefined
    static titileInput = document.getElementById("saveTitle")
    static descriptionInput = document.getElementById("saveDescription")
    static radioInput = document.querySelectorAll("input[name='saveRad']")
    static displayTask = document.getElementById("saveModal")


    constructor(){
        
    }
    static editSee(e){
        if(e.target.classList.contains("fa-edit")){
            this.idItem = e.target.parentElement.children[0].textContent
            this.toDo = JSON.parse(localStorage.getItem(`id_${this.idItem}`))

            this.contentDo = e.target.parentElement
            this.titileInput.value = this.toDo["titile"] 
            this.descriptionInput.value = this.toDo["description"]
            this.radioInput.forEach(elem => elem.value == this.toDo["radioTo"] ? elem.checked = true : null)
        
            this.displayTask.style.visibility = "visible" 
           
        }
       
    }
    static edit(){
                    
        document.getElementsByClassName("fa-times")[1].addEventListener("click", (e)=>{
            e.target.parentElement.style.visibility="hidden"
        })
        document.getElementById("saveTodo").addEventListener("click",function(e) {
            e.preventDefault()
            this.displayTask.style.visibility = "hidden"
            
            this.toDo["titile"] = this.titileInput.value 
            this.toDo["description"] = this.descriptionInput.value
            this.toDo["radioTo"] = document.querySelector("input[name='saveRad']:checked").value
            
            
            
            this.contentDo.children[1].textContent = this.toDo["titile"]
            this.contentDo.children[2].textContent = this.toDo["description"]
            this.contentDo.children[3].textContent = this.toDo["radioTo"]

            localStorage.setItem(`id_${this.idItem}`,JSON.stringify(this.toDo))

        }.bind(this))
        
    }
    static del(){
        document.getElementById("toDo").addEventListener("click",function(e) {
            if(e.target.classList.contains("fa-trash-alt")){
                let item = e.target.parentElement.children[0].textContent
                localStorage.removeItem(`id_${item}`)
                e.target.parentElement.remove()
                localStorage.length <= 1 ? localStorage.removeItem("id"):null
            }
        })
     
    }
    static postDoing(Doing){
        document.getElementById("toDo").addEventListener("click",function(e) {
            e.preventDefault()
            if(e.target.classList.contains("nextList")){
                e.target.parentElement.remove()
                
                let idDoing = e.target.parentElement.children[0].textContent
                let objectDoing = JSON.parse(localStorage.getItem(`id_${idDoing}`))
                
                objectDoing["doing"] = true

                Doing.doingMethod(objectDoing)

                localStorage.setItem(`id_${idDoing}`,JSON.stringify(objectDoing))
            }
           
            
        })
    }

}