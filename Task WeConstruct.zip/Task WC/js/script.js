"use strict";
import { Task } from "./task.js";
import {Adder} from "./adder.js"
import {Todo} from "./toDo.js"
import {Doing} from "./doing.js"
import {Done} from "./done.js"


let bool = true

document.getElementById("addButton").addEventListener("click", function(e){
    Task.displayTask(!bool)
})

Task.myMethod(Adder)

Adder.sortId(Doing)

Todo.del()
document.getElementById("toDo").addEventListener("click", function(e){
    Todo.editSee(e)
})
Todo.edit()

Todo.postDoing(Doing)
Doing.doingPost(Adder)
Done.getDoing(Adder)
Done.postDone()
Done.clearTodo()
Done.postDoing(Doing)
// Done.getDoing(Adder)