export class Done{
    constructor(){

    }
    static postDoing(Doing){
        document.getElementById("doneTask").addEventListener("click",function(e) {
                
            if(e.target.classList.contains("postDoing")){
                e.target.parentElement.remove()
                
                let idDoing = e.target.parentElement.children[0].textContent
                let objectDoing = JSON.parse(localStorage.getItem(`id_${idDoing}`))
                
                objectDoing["doing"] = true
                objectDoing["done"] = false

                Doing.doingMethod(objectDoing)

                localStorage.setItem(`id_${idDoing}`,JSON.stringify(objectDoing))
            }
        })
    }
    static getPost(itemObject){

            const doneDive = document.getElementById("doneTask")
            let doneItem = document.createElement("div")
            for(let i in itemObject){
                if(typeof itemObject[i] != typeof true ){
                    let doneSpan = document.createElement("span")
                    doneSpan.textContent = itemObject[i]
                    doneItem.append(doneSpan)
                }
            }
            
            let postClear = document.createElement("button")
            postClear.classList.add("postClear")
            let postDoing = document.createElement("button")
            postDoing.classList.add("postDoing")
            doneItem.classList.add("doneItem")

            postClear.textContent = "Clear"
            postDoing.textContent = "Doing"
            doneItem.append(postDoing,postClear)
            
            doneDive.prepend(doneItem)
    }
    static getDoing(Adder){
        document.getElementById("doingDiv").addEventListener("click", function(e){
            e.preventDefault()
            if(e.target.classList.contains("postDone")){
                
                e.target.parentElement.remove()
                let idDoing = e.target.parentElement.children[0].textContent
                let itemObject = JSON.parse(localStorage.getItem(`id_${idDoing}`))
                itemObject["done"] = true
                itemObject["doing"] = false
                console.log(itemObject)
                
                localStorage.setItem(`id_${idDoing}`,JSON.stringify(itemObject))
                Done.getPost(itemObject) 
            }
        })
    }
    static postDone(){
        for(let i in localStorage){
            if(localStorage.hasOwnProperty(i) &&  i.startsWith("id_") && JSON.parse(localStorage[i])["done"]){
                let itemObject = JSON.parse(localStorage[i])
                Done.getPost(itemObject) 
            }
        }
    }
    static clearTodo(){
        document.getElementById("doneTask").addEventListener("click",function(e){
            
            if(e.target.classList.contains("postClear")){
                let item = e.target.parentElement.children[0].textContent
                localStorage.removeItem(`id_${item}`)
                e.target.parentElement.remove()
                localStorage.length <= 1 ? localStorage.removeItem("id"):null
            }
        })   
    }
}