
export class Task{
  static id = localStorage.getItem("id") ? localStorage.getItem("id") :  0
  constructor(){
  }
  static displayTask(bool){
     
    const displayTask = document.getElementById("modal")

    if(bool) displayTask.style.visibility = "hidden"
    else displayTask.style.visibility = "visible" 
  }
  static myMethod(Adder){
      
        document.getElementById("addForm").addEventListener("submit",function(e) {
          
    
            e.preventDefault()
            const titileInput = document.getElementById("titile")
            const descriptionInput = document.getElementById("description")
            const radioInput = document.querySelector("input[name='radioTo']:checked")
            
            let toDo = {}
            toDo["id"] = ++Task.id

            toDo[titileInput.name] = titileInput.value
            toDo[descriptionInput.name] = descriptionInput.value
            toDo[radioInput.name] = radioInput.value
            toDo["doing"] = false
            toDo["done"] = false

            
            
            localStorage.setItem("id", Task.id)
            localStorage.setItem(`id_${Task.id}`,JSON.stringify(toDo))
            
            titileInput.value = ""
            descriptionInput.value  = ""
            radioInput.value = false

            Adder.adderSubmit(toDo)

            this.displayTask(true)
      }.bind(this))
  }
  
  
}
