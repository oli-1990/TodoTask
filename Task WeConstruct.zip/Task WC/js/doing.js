export class Doing{
    constructor(){

    }
    static doingPost(Adder){
        document.getElementById("doingDiv").addEventListener("click", function(e){
            e.preventDefault()
            if(e.target.classList.contains("postTodo")){
                e.target.parentElement.remove()
                
                let idDoing = e.target.parentElement.children[0].textContent
                let objectDoing = JSON.parse(localStorage.getItem(`id_${idDoing}`))
                
                objectDoing["doing"] = false
              
                Adder.adderSubmit(objectDoing)
                localStorage.setItem(`id_${idDoing}`,JSON.stringify(objectDoing))
            }
        })
    }
    static doingSort(localStorage){
        let sortLoc = Object.entries(localStorage).sort(function(a,b){
            let first  = JSON.parse(a[1]).id
            let second  = JSON.parse(b[1]).id
            if(first < second) return -1
            else if(first > second) return 1
            else return
        })
        return sortLoc
    }
    static doingMethod(objectDoing){
            const doingDiv = document.getElementById("doingDiv")
            let doingItem = document.createElement("div")
            for(let i in objectDoing){
                if(typeof objectDoing[i] != typeof true ){
                    let doingSpan = document.createElement("span")
                    doingSpan.textContent = objectDoing[i]
                    doingItem.append(doingSpan)
                }
            }
            let postDone = document.createElement("button")
            postDone.classList.add("postDone")
            let postTodo = document.createElement("button")
            postTodo.classList.add("postTodo")
            doingItem.classList.add("doingItem")

            postDone.textContent = "Done"
            postTodo.textContent = "To do"
            doingItem.append(postTodo,postDone)
            
            doingDiv.prepend(doingItem)
    }
    static doingLocal(localStorage){
        
        let objectDoing = Doing.doingSort(localStorage).reduce((acc,elem) => {
            JSON.parse(elem[1]).doing ?   acc.push( JSON.parse(elem[1])): null
            return acc
        },[])
        for(let i of objectDoing)  Doing.doingMethod(i)
    }
}