
export class Adder{
    constructor(){

    }
    static adderSubmit(object){
        const to = document.getElementsByClassName("toDo")[0]
        document.querySelector(".fa-times").addEventListener("click", (e)=>{
            e.target.parentElement.style.visibility="hidden"
        })  
        const div = document.createElement("div")
        div.classList.add("divList");

        
        const deleteTask=document.createElement("i");
        deleteTask.className="fas fa-trash-alt"
        const editTask=document.createElement("i");
        editTask.className="fas fa-edit"
        const myButton=document.createElement("button")
        myButton.classList.add("nextList")
        myButton.innerText="Doing"


        for(let i in object){
            if (object[i] == true && (i == "doing"|| i == "done")) return
            else if(typeof object[i] != typeof false ){
                let span = document.createElement("span")
                span.textContent = object[i]
                div.append(span,editTask, deleteTask, myButton)
           }
        }
        to.prepend(div)
        
    }

    static sortId(Doing){
        let local = []
        for(let i in localStorage){
            if (localStorage.hasOwnProperty(i) && i.startsWith("id_")){
                local.push(JSON.parse(localStorage[i]))
            }
        }
        local.sort(function(a,b){
            if(a.id < b.id) return -1
            else if(a.id > b.id) return 1
            else return
        })
        this.adder(local,Doing)
        
    }

    static adder(local,Doing){

        for(let i of local){
           this.adderSubmit(i)
        
        }
        
        Doing.doingLocal(localStorage)

    }

}